from django.apps import AppConfig


class CapybaraTgUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'capybara_tg_user'
    verbose_name = 'Users'
